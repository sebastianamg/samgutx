#ifndef __WEBGRAPH_3_6_11_H
#define __WEBGRAPH_3_6_11_H

#include <graal_isolate.h>


#if defined(__cplusplus)
extern "C" {
#endif

int load_graph(graal_isolatethread_t*, char*);

char* get_next_entry(graal_isolatethread_t*);

char* get_next_entry_wshift(graal_isolatethread_t*, int);

int run_main(int argc, char** argv);

#if defined(__cplusplus)
}
#endif
#endif
