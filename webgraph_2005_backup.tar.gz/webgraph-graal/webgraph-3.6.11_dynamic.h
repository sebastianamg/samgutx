#ifndef __WEBGRAPH_3_6_11_H
#define __WEBGRAPH_3_6_11_H

#include <graal_isolate_dynamic.h>


#if defined(__cplusplus)
extern "C" {
#endif

typedef int (*load_graph_fn_t)(graal_isolatethread_t*, char*);

typedef char* (*get_next_entry_fn_t)(graal_isolatethread_t*);

typedef char* (*get_next_entry_wshift_fn_t)(graal_isolatethread_t*, int);

typedef int (*run_main_fn_t)(int argc, char** argv);

#if defined(__cplusplus)
}
#endif
#endif
